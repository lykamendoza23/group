<?php
session_start();
include("connect.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['login'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            // User exists, set session
            $user = mysqli_fetch_assoc($result);
            $_SESSION['email'] = $user['email'];
            $_SESSION['firstName'] = $user['firstName'];
            header("Location: dashboard.php"); // Redirect to a dashboard or another page
        } else {
            echo "<p style='color: red;'>Invalid credentials. Please try again.</p>";
        }
    }
}
?>


<!DOCTYPE html>
   <html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <!--=============== FAVICON ===============-->
      <link rel="shortcut icon" href="/images/img/favicon.png" type="image/x-icon">

      <!--=============== REMIXICONS ===============-->
      <link href="https://cdn.jsdelivr.net/npm/remixicon@3.2.0/fonts/remixicon.css" rel="stylesheet">

      <!--=============== CSS ===============-->
      <link rel="stylesheet" href="style.css">

      <title>Wanderlust</title>
   </head>
   <body>
      <!--==================== HEADER ====================-->
      <header class="header" id="header">
         <nav class="nav container">
            <a href="#" class="nav__logo">
               Travel
            </a>

            <div class="nav__menu" id="nav-menu">
               <ul class="nav__list">
                  <li class="nav__item">
                     <a href="#home" class="nav__link active-link">Home</a>
                  </li>

                  <li class="nav__item">
                     <a href="#about" class="nav__link">About</a>
                  </li>

                  <li class="nav__item">
                     <a href="#popular" class="nav__link">Popular</a>
                  </li>

                  <li class="nav__item">
                     <a href="#explore" class="nav__link">Explore</a>
                  </li>

               </ul>

             <div class="nav__close" id="nav-close">
               <i class="ri-close-line"></i>

             </div>
            </div>

            <div class="nav__toggle" id="nav-toggle">
               <i class="ri-menu-fill"></i>
            </div>

         </nav>
      </header>


    <!--==================== MAIN ====================-->
    <main class="main">
        <!--==================== HOME ====================-->
        <section class="home section" id="home">
            <img src="images\save.jpg" alt="home background" class="home__bg">
            <div class="home__shadow"></div>

            <div class="home__container container grid">
                <div class="home__data">
                    <h3 class="home__subtitle">
                        Welcome to Wanderlust
                    </h3>
                     
                    <h1 class="home__title">
                        Discover Your Dream Destinations
                    </h1>

                    <p class="home__description">
                        Embark on an unforgettable journey, explore hidden gems, tranquil beaches, and majestic mountains. Your adventure starts now!
                    </p>

                    <a href="#" class="button">
                        Begin Your Adventure <i class="ri-arrow-right-line"></i>
                    </a>
                </div>

                <div class="home__cards grid">
                    <article class="home__card">
                        <img src="images\bali.jpg" alt="destination" class="home__card-img">
                        <h3 class="home__card-title">Bali, Indonesia</h3>
                        <div class="home__card-shadow"></div>
                    </article>

                    <article class="home__card">
                        <img src="images\kyoto.png" alt="destination" class="home__card-img">
                        <h3 class="home__card-title">Kyoto, Japan</h3>
                        <div class="home__card-shadow"></div>
                    </article>

                    <article class="home__card">
                        <img src="images\paris.jpg" alt="destination" class="home__card-img">
                        <h3 class="home__card-title">Paris, France</h3>
                        <div class="home__card-shadow"></div>
                    </article>

                    <article class="home__card">
                        <img src="images\sydney.webp" alt="destination" class="home__card-img">
                        <h3 class="home__card-title">Sydney, Australia</h3>
                        <div class="home__card-shadow"></div>
                    </article>
                </div>
            </div>
        </section>

        <!--==================== ABOUT ====================-->
        <section class="about section" id="about">
            <div class="about__container container grid">
                <div class="about__data">
                    <h2 class="section__title">
                        Learn More <br>
                        About Wanderlust
                    </h2>

                    <p class="about__description">
                        Travel is more than just a vacation, it's an exploration of new cultures, landscapes, and experiences. Join us on an unforgettable journey.
                    </p>

                    <a href="#" class="button">
                        Explore Our World <i class="ri-arrow-right-line"></i>
                    </a>
                </div>

                <div class="about__image">
                    <img src="images\TR.jpg" alt="about image" class="about__img">
                    <div class="about__shadow"></div>
                </div>
            </div>
        </section>

        <!--==================== DESTINATIONS ====================-->
        <section class="destinations section" id="destinations">
            <h2 class="section__title">
                Explore The Most Beautiful Places on Earth
            </h2>

            <div class="destinations__container container grid">
                <article class="destination__card">
                    <div class="destination__image">
                        <img src="images\grand.jpg" alt="destination" class="destination__img">
                        <div class="destination__shadow"></div>
                    </div>

                    <h2 class="destination__title">
                        Grand Canyon
                    </h2>

                    <div class="destination__location">
                        <i class="ri-map-pin-line"></i>
                        <span>USA</span>
                    </div>
                </article>

                <article class="destination__card">
                    <div class="destination__image">
                        <img src="images\greece.jpg" alt="destination" class="destination__img">
                        <div class="destination__shadow"></div>
                    </div>

                    <h2 class="destination__title">
                        Santorini
                    </h2>

                    <div class="destination__location">
                        <i class="ri-map-pin-line"></i>
                        <span>Greece</span>
                    </div>
                </article>

                <article class="destination__card">
                    <div class="destination__image">
                        <img src="images\Machu_Picchu,_Peru.jpg" alt="destination" class="destination__img">
                        <div class="destination__shadow"></div>
                    </div>

                    <h2 class="destination__title">
                        Machu Picchu
                    </h2>

                    <div class="destination__location">
                        <i class="ri-map-pin-line"></i>
                        <span>Peru</span>
                    </div>
                </article>
            </div>
        </section>

        <!--==================== JOIN ====================-->
        <section class="join section">
            <div class="join__container container grid">
                <div class="join__data">
                    <h2 class="section__title">
                        Start Your Adventure Today
                    </h2>
        
                    <p class="join__description">
                        Subscribe to our newsletter to stay up to date with the latest travel offers and destinations.
                    </p>
        
                    <form id="join-form" class="join__form" method="POST" action="">
                        <input type="email" id="email" placeholder="Enter your Email" class="join__input">
                        <button type="submit" class="join__button button">
                            Subscribe Now <i class="ri-arrow-right-line"></i>
                        </button>
                    </form>
                    <p id="response-message"></p>
                </div>
        
                <div class="join__image">
                    <img src="images\TRAVEL.avif" alt="join image" class="join__img">
                    <div class="join__shadow"></div>
                </div>
            </div>
        </section>

    <a href="index.html" class="indexpage-button">NEXT</a>

    <!--==================== FOOTER ====================-->
    <footer class="footer">
        <div class="footer__container container grid">
            <div class="footer__content grid">
                <div>
                    <a href="#" class="footer__logo">Wanderlust</a>
                    <p class="footer__description">
                        Travel with us and experience the world without limits.
                    </p>
                </div>

                <div class="footer__data grid">
                    <div>
                        <h3 class="footer__title">About Us</h3>
                        <ul class="footer__links">
                            <li><a href="#" class="footer__link">About Us</a></li>
                            <li><a href="#" class="footer__link">Features</a></li>
                            <li><a href="#" class="footer__link">News</a></li>
                        </ul>
                    </div>

                    <div>
                        <h3 class="footer__title">Contact</h3>
                        <ul class="footer__links">
                            <li><a href="#" class="footer__link">Contact Us</a></li>
                            <li><a href="#" class="footer__link">Support</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="footer__social">
                <a href="#" class="footer__social-icon"><i class="ri-facebook-circle-fill"></i></a>
                <a href="#" class="footer__social-icon"><i class="ri-twitter-fill"></i></a>
                <a href="#" class="footer__social-icon"><i class="ri-instagram-line"></i></a>
            </div>
        </div>
    </footer>
     
    <!--=============== JS SCRIPTS ===============-->
    <script src="main.js"></script>
</body>
</html>
