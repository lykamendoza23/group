document.addEventListener("DOMContentLoaded", function() {
   const loginForm = document.querySelector("form");

   loginForm.addEventListener("submit", function(event) {
       const email = document.querySelector("input[name='email']").value;
       const password = document.querySelector("input[name='password']").value;

       if (!email || !password) {
           event.preventDefault();
           alert("Please fill in both email and password.");
       }
   });
});
function handleFormSubmit(event) {
   event.preventDefault(); 

  
   const name = document.getElementById('name').value;
   const email = document.getElementById('email').value;
   const message = document.getElementById('message').value;

   if (name && email && message) {
      
       setTimeout(() => {
           
           document.getElementById('formResponse').textContent = `Thank you, ${name}! Your message has been sent.`;
           document.getElementById('formResponse').style.color = 'green';
       }, 500);  

       document.getElementById('contactForm').reset();
   } else {
       
       document.getElementById('formResponse').textContent = 'Please fill out all fields.';
       document.getElementById('formResponse').style.color = 'red';
   }
}

